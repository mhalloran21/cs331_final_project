# Lab 1: Login Security

## Useful Links

 * [Course Homepage](https://williams-cs.github.io/cs331-f21-www/)
 * [Lab Instructions](https://williams-cs.github.io/cs331-f21-www/assets/labs/1-lab.pdf)
 * [Pseudoterminal Reading](https://williams-cs.github.io/cs331-f21-www/assets/misc/pseudoterminals.pdf)
 * [Memory Management in C](https://williams-cs.github.io/cs331-f21-www/assets/misc/memory.html)
 * [A Simple Makefile Tutorial](http://www.cs.colby.edu/maxwell/courses/tutorials/maketutor/)

## Repository Contents

This repository contains the starter files for the login lab.

* You will add, at a minimum the following files:
  * `attack0.c`
  * `attack1.c`
  * `login0.c`
  * `login1.c`
  * `login2.c`
  * `pty.c`
* You will modify the following file:
  * `Makefile`
