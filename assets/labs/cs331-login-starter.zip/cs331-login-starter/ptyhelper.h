#ifndef PTYHELPER_H
#define PTYHELPER_H

int exec_on_pty(char **argv);

#endif // PTYHELPER_H
