#include <pty.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

/*
 * Creates a pty, starts a child process, attaches the master process and
 * the child process to the pty, and then returns the file descriptor of the
 * controlling side of the pty.
 */
int exec_on_pty(char **argv) {
    int pty_fd;

    pid_t pid;
    if ((pid = forkpty(&pty_fd, NULL, NULL, NULL)) < 0) {
        return EXIT_FAILURE;
    }

    if (pid) {
      return pty_fd; // parent
    } else {         // child
        execl(argv[0], argv[0], NULL);
        return EXIT_FAILURE;
    }
}
