/* STANDARD LIBRARY DEPENDENCIES */
#ifndef _HAVE_STDDEF_H
#define _HAVE_STDDEF_H
#include <stddef.h>
#endif /* _HAVE_STDDEF_H */

#ifndef _HAVE_STDIO_H
#define _HAVE_STDIO_H
#include <stdio.h>
#endif /* _HAVE_STDIO_H */

#ifndef _HAVE_STRING_H
#define _HAVE_STRING_H
#include <string.h>
#endif /* _HAVE_STRING_H */

#ifndef _csci331_console
#define _csci331_console

/* PUBLIC API DECLARATIONS */
char  *fgets_wrapper(char *, size_t, FILE *);
  
#endif /* _csci331_console */
