/* CONFORMANCE */
#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif /* _POSIX_C_SOURCE */

#ifndef _BSD_SOURCE
#define _BSD_SOURCE
#endif /* _BSD_SOURCE */

/* DEPENDENCIES */
#ifndef _HAVE_STDLIB_H
#define _HAVE_STDLIB_H
#include <stdlib.h>
#endif /* _HAVE_STDLIB_H */

#ifndef _HAVE_STRING_H
#define _HAVE_STRING_H
#include <string.h>
#endif /* _HAVE_STRING_H */

#ifndef _HAVE_STDIO_H
#define _HAVE_STDIO_H
#include <stdio.h>
#endif /* _HAVE_STDIO_H */

#ifndef _HAVE_STDBOOL_H
#define _HAVE_STDBOOL_H
#include <stdbool.h>
#endif /* _HAVE_STDBOOL_H */

#ifndef _csci331_database
#define _csci331_database

/* CONSTANTS */
#define ULEN 9
#define PWLEN 9

/* PUBLIC TYPE DECLARATIONS */
typedef struct pwent {
  char username[ULEN];
  char password[PWLEN];
} pwent_t;

typedef struct node {
  pwent_t data;
  struct node * next;
} list_t;

/* PUBLIC API DECLARATIONS */
list_t  *list_append(list_t *, pwent_t);
pwent_t *list_find(list_t *, const char *);
int      list_length(list_t *);
void     list_print(list_t *);
list_t  *read_pwdb(FILE *);

#endif /* _csci331_database */
