#include "console.h"

/**
 * Gets a string from a file and stores it in a buffer.
 * This function truncates the input if it is longer than
 * the destination buffer, null terminates the result,
 * and flushes the input file until either the next newline
 * or the end-of-file marker (EOF) is reached.
 *
 * @param a pointer to a destination buffer.
 * @param the size (in bytes) of the destination buffer.
 * @param a pointer to a file (e.g., STDIN)
 */
char  *fgets_wrapper(char *buffer, size_t buflen, FILE *fp)
{
    if (fgets(buffer, buflen, fp) != NULL)
    {
        size_t len = strlen(buffer);
        
        if (len > 0 && buffer[len - 1] == '\n') {
          // if the last character is a newline,
          // replace with NUL
          buffer[len - 1] = '\0';
        } else {
          // if the last character is not a newline,
          // read the rest of the input up to a newline
          // and discard it  
          int ch;
          while ((ch = getc(fp)) != EOF && ch != '\n') {
             ;
          }
        }
        
        return buffer;
    }
    return 0;
}
