#include "database.h"

/* PRIVATE IMPLEMENTATIONS */

/**
 * Recursive procedure that gets the length of the list
 * with the given head.  Not meant to be called directly.
 * @param a pointer to the head node of the list
 * @param the length of the list up to this sublist
 */
int __list_length(list_t * head, int count) {  
	if (head == NULL) {
		return count;
	}
  return __list_length(head->next, count + 1);
}

/**
 * A safer version of strcpy.  Blatantly stolen from OpenBSD.
 * 
 * @param a pointer to a string to modify
 * @param a pointer to a string to copy
 * @param number of bytes to copy
 */
size_t bsd_strlcpy(char *dst, const char *src, size_t dsize)
{
	const char *osrc = src;
	size_t nleft = dsize;

	/* Copy as many bytes as will fit. */
	if (nleft != 0) {
		while (--nleft != 0) {
			if ((*dst++ = *src++) == '\0')
				break;
		}
	}

	/* Not enough room in dst, add NUL and traverse rest of src. */
	if (nleft == 0) {
		if (dsize != 0)
			*dst = '\0';		/* NUL-terminate dst */
		while (*src++)
			;
	}

	return(src - osrc - 1);	/* count does not include NUL */
}

/* PUBLIC API IMPLEMENTATIONS */

/**
 * Appends a pwent_t struct to the list head. Works for
 * empty lists (i.e., head is NULL).
 *
 * @param the head of the list, or NULL if the list is empty.
 * @param a pwent_t struct containing password data.
 */
list_t *list_append(list_t * head, pwent_t data) {  
  list_t  *new_head = malloc(sizeof(list_t));
  new_head->data = data;
  new_head->next = head;
  return new_head;
}

/**
 * Finds the password entry for the given username. Returns
 * the returns pwent if successful, otherwise it returns null.
 * 
 * @param the head of the list
 */
pwent_t *list_find(list_t * head, const char * username) {
  list_t  *cur_node = head;
  while (cur_node != NULL) {
    // does cur_node contain the string that we want?
    if (strncmp(username, cur_node->data.username, ULEN)  == 0) {
      return &cur_node->data;
    }
    // otherwise, get the next item in the list and keep looking
    cur_node = cur_node->next;
  }
  // didn't find it
  return NULL;
}

/**
 * Computes the length of a list.
 *
 * @param a pointer to the head of the list
 */
int list_length(list_t * head) {
	return __list_length(head, 0);
}

/**
 * Prints each pwent in the list.
 *
 * @param a pointer to the head of the list
 */
void list_print(list_t * head) {
  list_t  *list = head;
  while(list != NULL) {
    printf("username = %s, password = %s\n",
           list->data.username,
           list->data.password);
    list = list->next;
  }
}

/**
 * Reads the given password database and returns
 * a linked list of pwent entries.
 *
 * @param a pointer to the database file.
 */
list_t *read_pwdb(FILE * file) {
  char    *line = NULL;
  size_t   linecap = 0;
  list_t  *list = NULL;

  while (getline(&line, &linecap, file) != -1) {
    // scan the string for the first occurrence of ':'
    // and replace it with '\0',
    // then do the same for '\n'.
    const char *delim = ":\n";
    char       *sepptr = line;
    char       *username = (char*)strsep(&sepptr, delim);
    char       *password = (char*)strsep(&sepptr, delim);
        
    // create pw entry
    pwent_t    *datap = malloc(sizeof(pwent_t));
    bsd_strlcpy((char *)datap->username, username, sizeof(datap->username));
    bsd_strlcpy((char *)datap->password, password, sizeof(datap->password));
    
    // append entry to list
    list = list_append(list, *datap);
  }
  
  free(line);

  return list;
}
